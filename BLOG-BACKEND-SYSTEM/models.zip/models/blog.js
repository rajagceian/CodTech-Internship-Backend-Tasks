const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const User = require('./user');

const Blog = sequelize.define('Blog', {
    title: DataTypes.STRING,
    content: DataTypes.TEXT,
});

Blog.belongsTo(User, { onDelete: 'CASCADE' });
User.hasMany(Blog);

module.exports = Blog;
