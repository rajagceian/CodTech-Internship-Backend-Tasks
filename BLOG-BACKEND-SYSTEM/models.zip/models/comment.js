const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const User = require('./user');
const Blog = require('./blog');

const Comment = sequelize.define('Comment', {
    content: DataTypes.TEXT,
});

Comment.belongsTo(User, { onDelete: 'CASCADE' });
Comment.belongsTo(Blog, { onDelete: 'CASCADE' });
User.hasMany(Comment);
Blog.hasMany(Comment);

module.exports = Comment;
