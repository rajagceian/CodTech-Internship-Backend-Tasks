const sequelize = require('../config/db');
const User = require('./user');
const Blog = require('./blog');
const Comment = require('./comment');

sequelize.sync();

module.exports = { sequelize, User, Blog, Comment };
