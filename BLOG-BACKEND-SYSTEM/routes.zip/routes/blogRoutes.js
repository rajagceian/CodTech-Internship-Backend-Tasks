const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createBlog, getAllBlogs } = require('../controllers/blogController');

router.post('/', auth, createBlog);
router.get('/', getAllBlogs);

module.exports = router;
