const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createComment, getComments } = require('../controllers/commentController');

router.post('/', auth, createComment);
router.get('/:blogId', getComments);

module.exports = router;
